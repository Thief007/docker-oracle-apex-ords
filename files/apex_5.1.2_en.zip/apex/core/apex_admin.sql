set define '^' verify off
prompt ...apex_admin
create or replace procedure apex_admin wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
4d 75
O3ONwW4mONkekAdo9aerQawUJ4kwg5nnm7+fMr2ywFxaVlo7465Z+tdHXrh0ixU23OK5QT9x
nmeP6GsvDnD2sA5I4HAncAHY4g7e10P8weDXpqZKc8v5

/
create or replace procedure htmldb_admin wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
35 6d
pjgDg7FvUM16vzB7kh2Hwv/goQ8wg5nnm7+fMr2ywFyFFvrXoaEYrln610deuHSLwMAy/tKG
Cabhxqax4zCAHw+uJPbR6iQf9jmmO7DLsA==

/
