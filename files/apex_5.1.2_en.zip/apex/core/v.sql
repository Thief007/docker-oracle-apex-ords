set define '^' verify off
prompt ...v
create or replace function v wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
423 15c
kBdLJPWuGTZQaSNIP1JLx4+x4gAwg80JmEoVfC8aM+p+F8gvRHnbodQxLwz/G5uD9OKbD2j+
tqy9ZLielLIFtDwnyb/JcTYlGXc2qktGG6vQlKYErCutTMXETJnOnexUtEXa1hbDEvXIC2us
gXPrg4gwPDLWv4SAOfqFaGQflEN/fHut1iiTCkG48dAU2N1rKLnoClTPGjMwfCF9f5Uyu6SF
D728oqtj6AKY4qRHSh/qtNXQE2+nBjECjkMLzT8JIGKHG630rYHofNC9Y1dbWUX/GFJ3JH9z
AriQyi3lx19jZFbYwjcEYoax7b9ox+X914w0tchYV5B5YVfhVAJyTw==

/
show errors
