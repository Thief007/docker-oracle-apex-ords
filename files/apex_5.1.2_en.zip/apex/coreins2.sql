Rem  Copyright (c) Oracle Corporation 1999 - 2016. All Rights Reserved.
Rem
Rem    NAME
Rem      coreins2.sql
Rem
Rem    DESCRIPTION
Rem      This is a primary installation script for Oracle APEX, but this should never be invoked directly.
Rem      This file should only be invoked by apexins.sql, the primary installation script for APEX.
Rem
Rem    NOTES
Rem      Ensure that all arguments (except image prefix) are entered in UPPERCASE.
Rem
Rem    REQUIREMENTS
Rem      - Oracle Database 10.2.0.3 or later
Rem      - PL/SQL Web Toolkit
Rem
Rem    Arguments:
Rem      1 - CDB_ROOT  = CDB installation into root
Rem      2 - UPGRADE   = Upgrade flag (1 = NO, 2 = YES)
Rem      3 - APPUN     = APEX schema name
Rem      4 - UFROM     = The prior APEX schema in an upgrade installation
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem      jstraub   02/20/2015 - Split from coreins.sql
Rem      cneumuel  10/17/2016 - Timing for copy_flow_meta_data (feature #1723)
Rem      cneumuel  10/21/2016 - reset package state to avoid ORA-04061 later on
Rem      cneumuel  11/28/2016 - Grant select on all tables in old schema, instead of SELECT ANY TABLE

set define '^'
set concat on
set concat .
set verify off
set autocommit off

define CDB_ROOT  = '^1'
define UPGRADE   = '^2'
define APPUN     = '^3'
define UFROM     = '^4'

rem prompt  IX.   U P G R A D E    O R A C L E   A P E X

alter session set current_schema = ^APPUN;

set serveroutput on
set feedback off
declare
    l_ufrom_enq varchar2(32767);
    l_appun_enq varchar2(32767);
    l_stmt      varchar2(32767);
begin
if '^UPGRADE' = '2' Then
    sys.dbms_application_info.set_action('upgrade');
    sys.dbms_output.put_line('');
    sys.dbms_output.put_line('   -- Now beginning upgrade. This will take several minutes.-------');
    sys.dbms_output.put_line('');
    sys.dbms_output.put_line('');
    --
    -- grant select on tables of old schema to new schema
    --
    l_ufrom_enq := sys.dbms_assert.enquote_name('^UFROM');
    l_appun_enq := sys.dbms_assert.enquote_name('^APPUN');
    for i in ( select object_name
                 from sys.dba_objects
                where owner       = '^UFROM'
                  and object_type = 'TABLE'
                  and object_name not like 'SYS%'
                 order by 1 )
    loop
        begin
            l_stmt := 'grant select on '||
                      l_ufrom_enq||'.'||sys.dbms_assert.enquote_name(i.object_name)||
                      'to '||l_appun_enq;
            execute immediate l_stmt;
        exception when others then
            sys.dbms_output.put_line('Grant failed: '||sqlerrm);
            sys.dbms_output.put_line('...'||l_stmt);
        end;
    end loop;
end if;
end;
/

timing start "Upgrade metadata 1"
begin
if '^UPGRADE' = '2' Then
    sys.dbms_output.put_line('   -- Migrating metadata to new schema -------');
    wwv_flow_upgrade.copy_flow_meta_data('^UFROM','^APPUN','^CDB_ROOT');
    commit;
end if;
end;
/
Rem
Rem avoid ORA-04061 after enabling/disabling constraints and triggers
Rem
exec sys.dbms_session.modify_package_state(sys.dbms_session.reinitialize)

timing stop
