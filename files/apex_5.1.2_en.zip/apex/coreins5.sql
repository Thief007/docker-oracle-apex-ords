Rem  Copyright (c) Oracle Corporation 1999 - 2016. All Rights Reserved.
Rem
Rem    NAME
Rem      coreins5.sql
Rem
Rem    DESCRIPTION
Rem      This is a primary installation script for Oracle APEX, but this should never be invoked directly.
Rem      This file should only be invoked by apexins.sql, the primary installation script for APEX.
Rem
Rem    NOTES
Rem      Ensure that all arguments (except image prefix) are entered in UPPERCASE.
Rem
Rem    REQUIREMENTS
Rem      - Oracle Database 10.2.0.3 or later
Rem      - PL/SQL Web Toolkit
Rem
Rem    Arguments:
Rem      1 - CDB_ROOT  = CDB installation into root
Rem      2 - UPGRADE   = Upgrade flag (1 = NO, 2 = YES)
Rem      3 - APPUN     = APEX schema name
Rem      4 - UFROM     = The prior APEX schema in an upgrade installation
Rem      5 - PREFIX    = The path to the file
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem      jstraub   02/20/2015 - Split from coreins.sql
Rem      jstraub   02/25/2015 - Added INSTALL_TYPE as a passed parameter
Rem      cneumuel  03/04/2015 - Moved revoke of select any table up before endins (which calls validate_apex) because it made objects invalid
Rem      cneumuel  10/17/2016 - Switch schemas, create APEX$SESSION, run flows_files_new2, apex_rest_config_core.sql (feature #1723)
Rem      cneumuel  11/28/2016 - Moved registry calls for upgrade and drop of old sys objects from coreins.sql
Rem      cneumuel  01/12/2017 - Register schemas before switching and migrating FLOWS_FILES (bug #25387702)
Rem      jstraub   04/06/2017 - Adapted for application container install (bug 24679331)
Rem      cneumuel  05/23/2017 - Use gen_adm_pwd.sql (bug #25790200)

set define '^'
set concat on
set concat .
set verify off
set autocommit off

define CDB_ROOT  = '^1'
define UPGRADE   = '^2'
define APPUN     = '^3'
define UFROM     = '^4'
define PREFIX    = '^5'
define INSTALL_TYPE = '^6'

prompt ...Upgrading DBMS_REGISTRY
declare
    l_schemas sys.dbms_registry.schema_list_t;
begin
    if '^INSTALL_TYPE' <> 'APPCONTAINER' then
        if '^UPGRADE' = '2' then
            if sys.dbms_registry.is_valid('APEX') is not null then
                sys.dbms_registry.upgrading('APEX','Oracle Application Express','validate_apex', '^APPUN');
            else --it has never been registered, so register it now
                sys.dbms_registry.loading('APEX','Oracle Application Express','validate_apex', '^APPUN');
            end if;
            sys.dbms_registry.set_required_comps('APEX', sys.dbms_registry.comp_depend_list_t('XDB'));
        end if;
        --
        select username
          bulk collect into l_schemas
          from all_users
         where username in ('FLOWS_FILES','APEX_PUBLIC_USER','APEX_LISTENER','APEX_REST_PUBLIC_USER','APEX_INSTANCE_ADMIN_USER')
         order by 1;
        sys.dbms_registry.update_schema_list('APEX', l_schemas);
    end if;
end;
/

alter session set current_schema = ^APPUN;
--
begin
    sys.dbms_output.put_line('   -- Switching Builder to new schema -------');
    wwv_flow_upgrade.set_environment('^INSTALL_TYPE');
    wwv_flow_upgrade.switch_schemas('^UFROM','^APPUN');
    commit;
end;
/
prompt  ...Installing flows_files objects 2
@^PREFIX.core/flows_files_new2.sql

create or replace context APEX$SESSION using ^APPUN..wwv_flow_session_context
/

--
-- Configure RESTful services for this instance if APEX_LISTENER exists
--
column thescript  new_val script
set termout off
select decode(has_rest, 1, 'apex_rest_config_core.sql', 'core/null1.sql') thescript
  from ( select count(*) has_rest
           from sys.dba_users
          where username = 'APEX_LISTENER' );
set termout on
@^PREFIX.gen_adm_pwd.sql
@^PREFIX.^script ^ADM_PWD ^ADM_PWD

prompt ...Remove objects created from previous APEX installations
declare
    l_dropped boolean;
    e_does_not_exist exception;
    pragma exception_init(e_does_not_exist,-942);
    procedure ddl(p_sql in varchar2)
    is
    begin
        sys.dbms_output.put_line('...'||p_sql);
        execute immediate p_sql;
        l_dropped := true;
    exception when e_does_not_exist then
        l_dropped := false;
    end ddl;
begin
    if '^UPGRADE' = '2' then
        ddl('drop view sys.flow_sessions');
        ddl('drop view sys.flow_parameters');
        ddl('drop view sys.flow_sqlarea');
        ddl('drop view sys.flow_sga');
        ddl('drop view sys.wwv_flow_gv$session');
        if l_dropped then
            -- can not keep old version because of dependencies
            ddl('drop package sys.wwv_dbms_sql');
        end if;
    end if;
end;
/

@^PREFIX.endins.sql

declare
    invalid_alter_priv exception;
    pragma exception_init(invalid_alter_priv,-02248);
begin
    if '^INSTALL_TYPE' <> 'APPCONTAINER' then
        execute immediate 'alter session set "_ORACLE_SCRIPT"=false';
    end if;
exception
    when invalid_alter_priv then
        null;
end;
/

prompt
prompt
prompt
prompt      Thank you for installing Oracle Application Express ^version.
prompt
prompt      Oracle Application Express is installed in the ^APPUN schema.
prompt
prompt      The structure of the link to the Application Express administration services is as follows:
prompt      http://host:port/pls/apex/apex_admin (Oracle HTTP Server with mod_plsql)
prompt      http://host:port/apex/apex_admin     (Oracle XML DB HTTP listener with the embedded PL/SQL gateway)
prompt      http://host:port/apex/apex_admin     (Oracle REST Data Services)
prompt
prompt      The structure of the link to the Application Express development interface is as follows:
prompt      http://host:port/pls/apex (Oracle HTTP Server with mod_plsql)
prompt      http://host:port/apex     (Oracle XML DB HTTP listener with the embedded PL/SQL gateway)
prompt      http://host:port/apex     (Oracle REST Data Services)
prompt

column global_name new_value gname
set termout off
select user global_name from sys.dual;
set termout on
set heading on
set feedback on
set sqlprompt '^gname> '
