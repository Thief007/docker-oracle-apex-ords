set define '^' verify off
prompt ...wwv_flows_release
create or replace function wwv_flows_release wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
69 92
QuZdnwf2wRoP4FjoC5dPz9R0KfMwg8eZgcfLCNL+XhaWlm2u2fqWlkqW8tehLlbcXOfAsr2y
m17nx3TAM7h0ZQm4dIvmOdziuUE/cZ5nqcoOo3cugXQ3UN1nct3mVezZPXKV7PumlWIEHQ==


/
