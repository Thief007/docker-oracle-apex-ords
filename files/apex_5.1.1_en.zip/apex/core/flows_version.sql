set define '^' verify off
prompt ...wwv_flows_version
create or replace function wwv_flows_version wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
7d 92
geoJXtLrwtnLWrehFlqtDCCu7Bcwg8eZgcfLCNL+XhaWlm2u2fqWlkqWDGLF/0dyXufAsr2y
m17nx3TAM7h0ZQm4dIsVW25xVQBzU46ppvCp7IxIkXAR6BdwaxeRUUjXQ/zB4NempjW2iNE=


/
