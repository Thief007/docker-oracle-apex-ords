set define '^' verify off
prompt ...popup_filter
create or replace function wwv_popup_filter wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
69 9e
K+0ypMjmPRvQ3Jy19WVQbYQecJ0wg8eZgcfLCNL+XhaWlm2WhZYWYuOu2Uc+oWIJ58CyvbKb
XufHdMAzuHRlCbh0i+b73OK5QT9xnmemXIgcHG+7i4Ys4sEcLI8sL6svu4sptgarkddD/MHg
16amdNz9Jw==

/
show errors
grant execute on wwv_popup_filter to public;
