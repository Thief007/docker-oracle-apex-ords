set define '^' verify off
prompt ...vrn
create or replace function vrn wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
97 ae
SskkSd/lcww6m865WcPc6HZqZfwwg8eZgcfLCNL+XhbVl15Qaefj/nRSgVyl0l7nx3TAM7h0
ZQlQw+fAsr2y5tNSdIsVptziuUE/cZ5nplykXauPhn2K5fuMaiHKyfb8TQqLjYtdTeUezgKS
zqlTyqvUDYvAgcctyaamEqRmuQ==

/
show errors
